const puppeteer = require('puppeteer');
const path = require('path');
const fs = require('fs');

const OUT_DIR = path.resolve('C:/Users/DELL/.gemini/antigravity/scratch/client-document-portal/handoff/screenshots');

if (!fs.existsSync(OUT_DIR)) {
  fs.mkdirSync(OUT_DIR, { recursive: true });
}

async function captureEnvironment(browser, baseUrl, envPrefix) {
  console.log(`\n======================================================`);
  console.log(`Starting capture for environment: ${envPrefix.toUpperCase()} (${baseUrl})`);
  console.log(`======================================================`);

  const page = await browser.newPage();

  // Helper wait
  const wait = ms => new Promise(r => setTimeout(r, ms));

  try {
    // 1. Client Desktop (1920x1080)
    console.log(`📸 [${envPrefix}] 1. Client Desktop View (1920x1080)...`);
    await page.setViewport({ width: 1920, height: 1080, deviceScaleFactor: 1 });
    await page.goto(`${baseUrl}/?chat=Dharmesh`, { waitUntil: 'networkidle2', timeout: 30000 });
    await wait(1500);
    const p1 = path.join(OUT_DIR, `${envPrefix}_01_client_desktop_1920x1080.png`);
    await page.screenshot({ path: p1, fullPage: false });
    console.log(`  ✓ Saved: ${p1}`);

    // 2. Client Mobile View (390x844)
    console.log(`📸 [${envPrefix}] 2. Client Mobile View (390x844)...`);
    await page.setViewport({ width: 390, height: 844, isMobile: true, hasTouch: true, deviceScaleFactor: 2 });
    await page.goto(`${baseUrl}/?chat=Dharmesh`, { waitUntil: 'networkidle2', timeout: 30000 });
    await wait(1200);
    const p2 = path.join(OUT_DIR, `${envPrefix}_02_client_mobile_390x844.png`);
    await page.screenshot({ path: p2, fullPage: false });
    console.log(`  ✓ Saved: ${p2}`);

    // Reset viewport for desktop modal captures
    await page.setViewport({ width: 1920, height: 1080, deviceScaleFactor: 1 });

    // 3. Client Onboarding Setup Modal (#nameModal)
    console.log(`📸 [${envPrefix}] 3. Client Onboarding Setup Modal (#nameModal)...`);
    await page.evaluate(() => {
      const modal = document.getElementById('nameModal');
      if (modal) modal.classList.remove('hidden');
    });
    await wait(700);
    const p3 = path.join(OUT_DIR, `${envPrefix}_03_client_modal_onboarding_nameModal.png`);
    await page.screenshot({ path: p3 });
    console.log(`  ✓ Saved: ${p3}`);

    // Hide onboarding modal
    await page.evaluate(() => {
      const modal = document.getElementById('nameModal');
      if (modal) modal.classList.add('hidden');
    });
    await wait(300);

    // 4. "My Profile" Modal in View Mode (#clientProfileModal)
    console.log(`📸 [${envPrefix}] 4. "My Profile" Modal in View Mode (#clientProfileModal)...`);
    await page.evaluate(() => {
      if (typeof openClientProfileModal === 'function') {
        openClientProfileModal();
      } else {
        const btn = document.getElementById('headerProfileBtn');
        if (btn) btn.click();
      }
    });
    await wait(800);
    const p4 = path.join(OUT_DIR, `${envPrefix}_04_client_modal_profile_view.png`);
    await page.screenshot({ path: p4 });
    console.log(`  ✓ Saved: ${p4}`);

    // 5. "My Profile" Modal in Edit Mode (#clientProfileModal with edit form)
    console.log(`📸 [${envPrefix}] 5. "My Profile" Modal in Edit Mode...`);
    await page.evaluate(() => {
      if (typeof toggleProfileInlineEdit === 'function') {
        toggleProfileInlineEdit();
      } else {
        const btn = document.getElementById('editProfileToggleBtn');
        if (btn) btn.click();
      }
    });
    await wait(800);
    const p5 = path.join(OUT_DIR, `${envPrefix}_05_client_modal_profile_edit.png`);
    await page.screenshot({ path: p5 });
    console.log(`  ✓ Saved: ${p5}`);

    // Close profile modal
    await page.evaluate(() => {
      if (typeof closeClientProfileModal === 'function') {
        closeClientProfileModal();
      }
    });
    await wait(400);

    // 6. Raoprime Organization Info Modal (#profileModal)
    console.log(`📸 [${envPrefix}] 6. Raoprime Organization Info Modal (#profileModal)...`);
    await page.evaluate(() => {
      if (typeof openProfileModal === 'function') {
        openProfileModal();
      } else {
        const heading = document.getElementById('chatHeading');
        if (heading) heading.click();
      }
    });
    await wait(800);
    const p6 = path.join(OUT_DIR, `${envPrefix}_06_client_modal_organization_profileModal.png`);
    await page.screenshot({ path: p6 });
    console.log(`  ✓ Saved: ${p6}`);

    // Close organization info modal
    await page.evaluate(() => {
      if (typeof closeProfileModal === 'function') {
        closeProfileModal();
      }
    });
    await wait(400);

    // 7. Client Image Lightbox Modal (#photoLightboxModal)
    console.log(`📸 [${envPrefix}] 7. Client Image Lightbox Modal (#photoLightboxModal)...`);
    await page.evaluate(() => {
      if (typeof openPhotoLightbox === 'function') {
        openPhotoLightbox('/assets/rp-logo.jpg');
      } else {
        const modal = document.getElementById('photoLightboxModal');
        const img = document.getElementById('lightboxPhotoImg');
        if (img) img.src = '/assets/rp-logo.jpg';
        if (modal) modal.classList.remove('hidden');
      }
    });
    await wait(800);
    const p7 = path.join(OUT_DIR, `${envPrefix}_07_client_modal_image_lightbox.png`);
    await page.screenshot({ path: p7 });
    console.log(`  ✓ Saved: ${p7}`);

    // Close lightbox
    await page.evaluate(() => {
      if (typeof closePhotoLightbox === 'function') {
        closePhotoLightbox();
      } else {
        const modal = document.getElementById('photoLightboxModal');
        if (modal) modal.classList.add('hidden');
      }
    });
    await wait(400);

    // ---------------- ADMIN VIEWS ----------------

    // 8. Admin Login Gateway Lock Screen
    console.log(`📸 [${envPrefix}] 8. Admin Login Gateway Lock Screen...`);
    await page.goto(`${baseUrl}/admin`, { waitUntil: 'networkidle2', timeout: 30000 });
    // Clear any existing session
    await page.evaluate(() => {
      sessionStorage.clear();
      localStorage.clear();
      const gateway = document.getElementById('loginGateway');
      if (gateway) gateway.classList.remove('hidden');
    });
    await wait(800);
    const p8 = path.join(OUT_DIR, `${envPrefix}_08_admin_login_gateway.png`);
    await page.screenshot({ path: p8 });
    console.log(`  ✓ Saved: ${p8}`);

    // 9. Authenticated Admin Console Overview
    console.log(`📸 [${envPrefix}] 9. Authenticated Admin Console Overview...`);
    await page.type('#adminPasswordInput', 'rdmy', { delay: 50 });
    await page.click('#unlockBtn');
    await wait(2000);
    const p9 = path.join(OUT_DIR, `${envPrefix}_09_admin_console_overview.png`);
    await page.screenshot({ path: p9 });
    console.log(`  ✓ Saved: ${p9}`);

    // 10. Admin Active Conversation View
    console.log(`📸 [${envPrefix}] 10. Admin Active Conversation View...`);
    // Click Dharmesh conversation or first conversation item
    const clickedConvo = await page.evaluate(() => {
      const convos = Array.from(document.querySelectorAll('.conversation-item'));
      const dharmeshConvo = convos.find(el => el.textContent.includes('Dharmesh'));
      const target = dharmeshConvo || convos[0];
      if (target) {
        target.click();
        return true;
      }
      return false;
    });
    await wait(1500);
    const p10 = path.join(OUT_DIR, `${envPrefix}_10_admin_active_conversation.png`);
    await page.screenshot({ path: p10 });
    console.log(`  ✓ Saved: ${p10}`);

    // 11. Admin Client Device & Telemetry Intelligence Modal (#clientIntelModal)
    console.log(`📸 [${envPrefix}] 11. Admin Client Intelligence Modal (#clientIntelModal)...`);
    await page.evaluate(() => {
      if (typeof openClientIntelModal === 'function') {
        openClientIntelModal();
      } else {
        const btn = document.getElementById('clientIntelBtn');
        if (btn) btn.click();
      }
    });
    await wait(1000);
    const p11 = path.join(OUT_DIR, `${envPrefix}_11_admin_modal_client_intel.png`);
    await page.screenshot({ path: p11 });
    console.log(`  ✓ Saved: ${p11}`);

    // Close intel modal
    await page.evaluate(() => {
      if (typeof closeClientIntelModal === 'function') {
        closeClientIntelModal();
      }
    });
    await wait(400);

    // 12. Admin Rename Modal (#renameChatModal)
    console.log(`📸 [${envPrefix}] 12. Admin Rename Modal (#renameChatModal)...`);
    await page.evaluate(() => {
      if (typeof openRenameModal === 'function') {
        openRenameModal();
      } else {
        const modal = document.getElementById('renameChatModal');
        if (modal) modal.classList.remove('hidden');
      }
    });
    await wait(600);
    const p12 = path.join(OUT_DIR, `${envPrefix}_12_admin_modal_rename_chat.png`);
    await page.screenshot({ path: p12 });
    console.log(`  ✓ Saved: ${p12}`);

    // Close rename modal
    await page.evaluate(() => {
      if (typeof closeRenameModal === 'function') {
        closeRenameModal();
      } else {
        const modal = document.getElementById('renameChatModal');
        if (modal) modal.classList.add('hidden');
      }
    });
    await wait(400);

    // 13. Admin Delete Confirmation Modal (#deleteChatModal)
    console.log(`📸 [${envPrefix}] 13. Admin Delete Confirmation Modal (#deleteChatModal)...`);
    await page.evaluate(() => {
      if (typeof confirmDeleteActiveChat === 'function') {
        confirmDeleteActiveChat();
      } else {
        const modal = document.getElementById('deleteChatModal');
        if (modal) modal.classList.remove('hidden');
      }
    });
    await wait(600);
    const p13 = path.join(OUT_DIR, `${envPrefix}_13_admin_modal_delete_chat.png`);
    await page.screenshot({ path: p13 });
    console.log(`  ✓ Saved: ${p13}`);

    // Close delete modal
    await page.evaluate(() => {
      if (typeof closeDeleteModal === 'function') {
        closeDeleteModal();
      } else {
        const modal = document.getElementById('deleteChatModal');
        if (modal) modal.classList.add('hidden');
      }
    });
    await wait(400);

    // 14. Admin Photo Verification Approval Modal (#adminPhotoModal)
    console.log(`📸 [${envPrefix}] 14. Admin Photo Verification Modal (#adminPhotoModal)...`);
    await page.evaluate(() => {
      if (typeof viewClientVerifiedPhoto === 'function') {
        viewClientVerifiedPhoto(
          'https://lh3.googleusercontent.com/a/ACg8ocLM4e9iD7orOAZxXoGqqCeUXWxhFp_Gj-GJ0eW1rYzFlsfpUhE=s96-c',
          'Dharmesh',
          'xraoprime@gmail.com',
          'google'
        );
      } else {
        const modal = document.getElementById('adminPhotoModal');
        if (modal) modal.classList.remove('hidden');
      }
    });
    await wait(600);
    const p14 = path.join(OUT_DIR, `${envPrefix}_14_admin_modal_photo_verification.png`);
    await page.screenshot({ path: p14 });
    console.log(`  ✓ Saved: ${p14}`);

    // Close photo verification modal
    await page.evaluate(() => {
      if (typeof closeAdminPhotoModal === 'function') {
        closeAdminPhotoModal();
      }
    });
    await wait(400);

    console.log(`\n✅ Completed all 14 visual captures for [${envPrefix}]!`);
  } catch (err) {
    console.error(`❌ Error capturing [${envPrefix}]:`, err);
    throw err;
  } finally {
    await page.close();
  }
}

async function run() {
  console.log('🚀 Starting Puppeteer for Milestone M1 Visual Captures...');
  const browser = await puppeteer.launch({
    headless: 'new',
    args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-dev-shm-usage', '--window-size=1920,1080']
  });

  try {
    // Local capture
    await captureEnvironment(browser, 'http://localhost:4000', 'local');

    // Live capture
    await captureEnvironment(browser, 'https://raoprime.onrender.com', 'live');

    console.log('\n🎉 ALL 28 HIGH-RESOLUTION SCREENSHOTS CAPTURED SUCCESSFULLY!');
  } finally {
    await browser.close();
  }
}

run().catch(err => {
  console.error('Fatal capture failure:', err);
  process.exit(1);
});
